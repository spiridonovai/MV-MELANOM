# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

from tvtk.tvtk_classes.open_gl_poly_data_mapper import OpenGLPolyDataMapper


class OpenGLSphereMapper(OpenGLPolyDataMapper):
    """
    OpenGLSphereMapper - draw spheres using imposters
    
    Superclass: OpenGLPolyDataMapper
    
    An open_gl mapper that uses imposters to draw spheres. Supports
    transparency and picking as well.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkOpenGLSphereMapper, obj, update, **traits)
    
    radius = traits.Float(0.30000001192092896, enter_set=True, auto_set=False, help=\
        """
        This value will be used for the radius is the scale array is not
        provided.
        """
    )

    def _radius_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRadius,
                        self.radius)

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, help=\
        """
        Specify the input data to map.
        """
    )

    def set_scale_array(self, *args):
        """
        V.set_scale_array(string)
        C++: virtual void SetScaleArray(const char *_arg)
        Convenience method to set the array to scale with.
        """
        ret = self._wrap_call(self._vtk_obj.SetScaleArray, *args)
        return ret

    _updateable_traits_ = \
    (('geometry_shader_code', 'GetGeometryShaderCode'),
    ('reference_count', 'GetReferenceCount'), ('array_id', 'GetArrayId'),
    ('number_of_pieces', 'GetNumberOfPieces'), ('progress_text',
    'GetProgressText'), ('field_data_tuple_id', 'GetFieldDataTupleId'),
    ('populate_selection_settings', 'GetPopulateSelectionSettings'),
    ('ghost_level', 'GetGhostLevel'), ('render_time', 'GetRenderTime'),
    ('piece', 'GetPiece'), ('scalar_visibility', 'GetScalarVisibility'),
    ('cell_id_array_name', 'GetCellIdArrayName'), ('color_mode',
    'GetColorMode'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('number_of_sub_pieces', 'GetNumberOfSubPieces'), ('static',
    'GetStatic'), ('point_id_array_name', 'GetPointIdArrayName'),
    ('debug', 'GetDebug'), ('vertex_shader_code', 'GetVertexShaderCode'),
    ('use_lookup_table_scalar_range', 'GetUseLookupTableScalarRange'),
    ('radius', 'GetRadius'), ('resolve_coincident_topology',
    'GetResolveCoincidentTopology'), ('abort_execute', 'GetAbortExecute'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('array_access_mode', 'GetArrayAccessMode'),
    ('composite_id_array_name', 'GetCompositeIdArrayName'),
    ('resolve_coincident_topology_polygon_offset_faces',
    'GetResolveCoincidentTopologyPolygonOffsetFaces'), ('array_name',
    'GetArrayName'), ('scalar_mode', 'GetScalarMode'),
    ('fragment_shader_code', 'GetFragmentShaderCode'), ('progress',
    'GetProgress'), ('array_component', 'GetArrayComponent'),
    ('resolve_coincident_topology_z_shift',
    'GetResolveCoincidentTopologyZShift'), ('process_id_array_name',
    'GetProcessIdArrayName'), ('scalar_range', 'GetScalarRange'),
    ('interpolate_scalars_before_mapping',
    'GetInterpolateScalarsBeforeMapping'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'interpolate_scalars_before_mapping', 'release_data_flag',
    'scalar_visibility', 'static', 'use_lookup_table_scalar_range',
    'color_mode', 'resolve_coincident_topology', 'scalar_mode',
    'array_access_mode', 'array_component', 'array_id', 'array_name',
    'cell_id_array_name', 'composite_id_array_name',
    'field_data_tuple_id', 'fragment_shader_code', 'geometry_shader_code',
    'ghost_level', 'number_of_pieces', 'number_of_sub_pieces', 'piece',
    'point_id_array_name', 'populate_selection_settings',
    'process_id_array_name', 'progress_text', 'radius', 'render_time',
    'resolve_coincident_topology_polygon_offset_faces',
    'resolve_coincident_topology_z_shift', 'scalar_range',
    'vertex_shader_code'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(OpenGLSphereMapper, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit OpenGLSphereMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['interpolate_scalars_before_mapping', 'scalar_visibility',
            'static', 'use_lookup_table_scalar_range'], ['color_mode',
            'resolve_coincident_topology', 'scalar_mode'], ['array_access_mode',
            'array_component', 'array_id', 'array_name', 'cell_id_array_name',
            'composite_id_array_name', 'field_data_tuple_id',
            'fragment_shader_code', 'geometry_shader_code', 'ghost_level',
            'number_of_pieces', 'number_of_sub_pieces', 'piece',
            'point_id_array_name', 'populate_selection_settings',
            'process_id_array_name', 'radius', 'render_time',
            'resolve_coincident_topology_polygon_offset_faces',
            'resolve_coincident_topology_z_shift', 'scalar_range',
            'vertex_shader_code']),
            title='Edit OpenGLSphereMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit OpenGLSphereMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

