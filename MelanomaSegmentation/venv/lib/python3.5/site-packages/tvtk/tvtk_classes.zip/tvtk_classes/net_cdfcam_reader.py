# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

from tvtk.tvtk_classes.unstructured_grid_algorithm import UnstructuredGridAlgorithm


class NetCDFCAMReader(UnstructuredGridAlgorithm):
    """
    NetCDFCAMReader - Read unstructured net_cdf CAM files.
    
    Superclass: UnstructuredGridAlgorithm
    
    Reads in a net_cdf CAM (Community Atmospheric Model) file and produces
    and unstructured grid.  The grid is actually unstructured in the X
    and Y directions and rectilinear in the Z direction. If we read one
    layer we produce quad cells otherwise we produce hex cells.  The
    reader requires 2 net_cdf files: the main file has all attributes, the
    connectivity file has point positions and cell connectivity
    information.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkNetCDFCAMReader, obj, update, **traits)
    
    single_midpoint_layer = tvtk_base.false_bool_trait(help=\
        """
        If single_xxx_layer is 1, we'll load only the layer specified by
        xxx_layer_index.  Otherwise, we load all layers. We do that for
        midpoint layer variables ( which have dimension 'lev') or for
        interface layer variables (which have dimension 'ilev').
        """
    )

    def _single_midpoint_layer_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSingleMidpointLayer,
                        self.single_midpoint_layer_)

    single_interface_layer = tvtk_base.false_bool_trait(help=\
        """
        If single_xxx_layer is 1, we'll load only the layer specified by
        xxx_layer_index.  Otherwise, we load all layers. We do that for
        midpoint layer variables ( which have dimension 'lev') or for
        interface layer variables (which have dimension 'ilev').
        """
    )

    def _single_interface_layer_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSingleInterfaceLayer,
                        self.single_interface_layer_)

    file_name = tvtk_base.vtk_file_name("", help=\
        """
        
        """
    )

    def _file_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFileName,
                        self.file_name)

    midpoint_layer_index = traits.Int(0, enter_set=True, auto_set=False, help=\
        """
        If single_xxx_layer is 1, we'll load only the layer specified by
        xxx_layer_index.  Otherwise, we load all layers. We do that for
        midpoint layer variables ( which have dimension 'lev') or for
        interface layer variables (which have dimension 'ilev').
        """
    )

    def _midpoint_layer_index_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMidpointLayerIndex,
                        self.midpoint_layer_index)

    vertical_dimension = traits.Trait(1, traits.Range(0, 2, enter_set=True, auto_set=False), help=\
        """
        Set whether to read a single layer, midpoint layers or interface
        layers. VERTICAL_DIMENSION_SINGLE_LAYER (0) indicates that only a
        single layer will be read in. The net_cdf variables loaded will be
        the ones with dimensions (time, ncol).
        VERTICAL_DIMENSION_MIDPOINT_LAYERS (1) indicates that variables
        defined on midpoint layers will be read in. These are variables
        with dimensions (time, lev, ncol).
        VERTICAL_DIMENSION_INTERFACE_LAYERS (2) indicates that variables
        defined on interface layers will be read in. These are variables
        with dimensions (time, ilev, ncol).
        """
    )

    def _vertical_dimension_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetVerticalDimension,
                        self.vertical_dimension)

    def get_point_array_status(self, *args):
        """
        V.get_point_array_status(string) -> int
        C++: int GetPointArrayStatus(const char *name)
        The following methods allow selective reading of variables. By
        default, ALL data variables on the nodes are read.
        """
        ret = self._wrap_call(self._vtk_obj.GetPointArrayStatus, *args)
        return ret

    def set_point_array_status(self, *args):
        """
        V.set_point_array_status(string, int)
        C++: void SetPointArrayStatus(const char *name, int status)
        The following methods allow selective reading of variables. By
        default, ALL data variables on the nodes are read.
        """
        ret = self._wrap_call(self._vtk_obj.SetPointArrayStatus, *args)
        return ret

    interface_layer_index = traits.Int(0, enter_set=True, auto_set=False, help=\
        """
        If single_xxx_layer is 1, we'll load only the layer specified by
        xxx_layer_index.  Otherwise, we load all layers. We do that for
        midpoint layer variables ( which have dimension 'lev') or for
        interface layer variables (which have dimension 'ilev').
        """
    )

    def _interface_layer_index_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetInterfaceLayerIndex,
                        self.interface_layer_index)

    connectivity_file_name = tvtk_base.vtk_file_name("", help=\
        """
        
        """
    )

    def _connectivity_file_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetConnectivityFileName,
                        self.connectivity_file_name)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            help="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        V.get_input(int) -> DataObject
        C++: DataObject *GetInput(int port)
        V.get_input() -> DataObject
        C++: DataObject *GetInput()"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    def _get_interface_layers_range(self):
        return self._vtk_obj.GetInterfaceLayersRange()
    interface_layers_range = traits.Property(_get_interface_layers_range, help=\
        """
        
        """
    )

    def _get_midpoint_layers_range(self):
        return self._vtk_obj.GetMidpointLayersRange()
    midpoint_layers_range = traits.Property(_get_midpoint_layers_range, help=\
        """
        
        """
    )

    def _get_number_of_point_arrays(self):
        return self._vtk_obj.GetNumberOfPointArrays()
    number_of_point_arrays = traits.Property(_get_number_of_point_arrays, help=\
        """
        The following methods allow selective reading of variables. By
        default, ALL data variables on the nodes are read.
        """
    )

    def get_point_array_name(self, *args):
        """
        V.get_point_array_name(int) -> string
        C++: const char *GetPointArrayName(int index)
        The following methods allow selective reading of variables. By
        default, ALL data variables on the nodes are read.
        """
        ret = self._wrap_call(self._vtk_obj.GetPointArrayName, *args)
        return ret

    def can_read_file(self, *args):
        """
        V.can_read_file(string) -> int
        C++: static int CanReadFile(const char *fileName)
        Returns 1 if this file can be read and 0 if the file cannot be
        read. Because net_cdf CAM files come in pairs and we only check
        one of the files, the result is not definitive.  Invalid files
        may still return 1 although a valid file will never return 0.
        """
        ret = self._wrap_call(self._vtk_obj.CanReadFile, *args)
        return ret

    def disable_all_point_arrays(self):
        """
        V.disable_all_point_arrays()
        C++: void DisableAllPointArrays()
        The following methods allow selective reading of variables. By
        default, ALL data variables on the nodes are read.
        """
        ret = self._vtk_obj.DisableAllPointArrays()
        return ret
        

    def enable_all_point_arrays(self):
        """
        V.enable_all_point_arrays()
        C++: void EnableAllPointArrays()
        The following methods allow selective reading of variables. By
        default, ALL data variables on the nodes are read.
        """
        ret = self._vtk_obj.EnableAllPointArrays()
        return ret
        

    _updateable_traits_ = \
    (('interface_layer_index', 'GetInterfaceLayerIndex'),
    ('single_midpoint_layer', 'GetSingleMidpointLayer'),
    ('vertical_dimension', 'GetVerticalDimension'),
    ('connectivity_file_name', 'GetConnectivityFileName'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('reference_count',
    'GetReferenceCount'), ('abort_execute', 'GetAbortExecute'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('file_name',
    'GetFileName'), ('progress_text', 'GetProgressText'), ('debug',
    'GetDebug'), ('midpoint_layer_index', 'GetMidpointLayerIndex'),
    ('single_interface_layer', 'GetSingleInterfaceLayer'), ('progress',
    'GetProgress'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'single_interface_layer',
    'single_midpoint_layer', 'connectivity_file_name', 'file_name',
    'interface_layer_index', 'midpoint_layer_index', 'progress_text',
    'vertical_dimension'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(NetCDFCAMReader, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit NetCDFCAMReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['single_interface_layer', 'single_midpoint_layer'], [],
            ['connectivity_file_name', 'file_name', 'interface_layer_index',
            'midpoint_layer_index', 'vertical_dimension']),
            title='Edit NetCDFCAMReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit NetCDFCAMReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

